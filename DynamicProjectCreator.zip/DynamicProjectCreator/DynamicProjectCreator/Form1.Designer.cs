﻿namespace DynamicProjectCreator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProjectName = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.txtProjectName = new System.Windows.Forms.TextBox();
            this.chkUIHandler = new System.Windows.Forms.CheckBox();
            this.chkWeb = new System.Windows.Forms.CheckBox();
            this.lblArchitecture = new System.Windows.Forms.Label();
            this.cmbArchitecture = new System.Windows.Forms.ComboBox();
            this.lblVisualStudioVersion = new System.Windows.Forms.Label();
            this.cmbVSVersion = new System.Windows.Forms.ComboBox();
            this.lblCountry = new System.Windows.Forms.Label();
            this.cmbCountry = new System.Windows.Forms.ComboBox();
            this.grpClient = new System.Windows.Forms.GroupBox();
            this.grpWeb = new System.Windows.Forms.GroupBox();
            this.chkModel = new System.Windows.Forms.CheckBox();
            this.grpCommon = new System.Windows.Forms.GroupBox();
            this.chkServiceCalls = new System.Windows.Forms.CheckBox();
            this.chkHelpers = new System.Windows.Forms.CheckBox();
            this.grpCore = new System.Windows.Forms.GroupBox();
            this.grpAPIService = new System.Windows.Forms.GroupBox();
            this.chkWebAPI = new System.Windows.Forms.CheckBox();
            this.grpEntities = new System.Windows.Forms.GroupBox();
            this.chkEntities = new System.Windows.Forms.CheckBox();
            this.grpBAL = new System.Windows.Forms.GroupBox();
            this.chkBAL = new System.Windows.Forms.CheckBox();
            this.grpDAL = new System.Windows.Forms.GroupBox();
            this.chkDAL = new System.Windows.Forms.CheckBox();
            this.grpCrossCutting = new System.Windows.Forms.GroupBox();
            this.chkAutoMapper = new System.Windows.Forms.CheckBox();
            this.chkExceptionHandler = new System.Windows.Forms.CheckBox();
            this.chkWebService = new System.Windows.Forms.CheckBox();
            this.chkGlobalHandler = new System.Windows.Forms.CheckBox();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.lblSelectFolder = new System.Windows.Forms.Label();
            this.txtFolderPath = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.grpDB = new System.Windows.Forms.GroupBox();
            this.chkDB = new System.Windows.Forms.CheckBox();
            this.chkSecurityCryptography = new System.Windows.Forms.CheckBox();
            this.chkModels = new System.Windows.Forms.CheckBox();
            this.chkLogging = new System.Windows.Forms.CheckBox();
            this.chkDataAccess = new System.Windows.Forms.CheckBox();
            this.chkUSWeb = new System.Windows.Forms.CheckBox();
            this.grpClient.SuspendLayout();
            this.grpWeb.SuspendLayout();
            this.grpCommon.SuspendLayout();
            this.grpCore.SuspendLayout();
            this.grpAPIService.SuspendLayout();
            this.grpEntities.SuspendLayout();
            this.grpBAL.SuspendLayout();
            this.grpDAL.SuspendLayout();
            this.grpCrossCutting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.grpDB.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Location = new System.Drawing.Point(27, 124);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(71, 13);
            this.lblProjectName.TabIndex = 0;
            this.lblProjectName.Text = "Project Name";
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(58, 492);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 1;
            this.btnCreate.Text = "Create";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtProjectName
            // 
            this.txtProjectName.Location = new System.Drawing.Point(152, 121);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(100, 20);
            this.txtProjectName.TabIndex = 2;
            // 
            // chkUIHandler
            // 
            this.chkUIHandler.AutoSize = true;
            this.chkUIHandler.Location = new System.Drawing.Point(21, 19);
            this.chkUIHandler.Name = "chkUIHandler";
            this.chkUIHandler.Size = new System.Drawing.Size(74, 17);
            this.chkUIHandler.TabIndex = 5;
            this.chkUIHandler.Text = "UIHandler";
            this.chkUIHandler.UseVisualStyleBackColor = true;
            // 
            // chkWeb
            // 
            this.chkWeb.AutoSize = true;
            this.chkWeb.Location = new System.Drawing.Point(21, 34);
            this.chkWeb.Name = "chkWeb";
            this.chkWeb.Size = new System.Drawing.Size(49, 17);
            this.chkWeb.TabIndex = 6;
            this.chkWeb.Text = "Web";
            this.chkWeb.UseVisualStyleBackColor = true;
            // 
            // lblArchitecture
            // 
            this.lblArchitecture.AutoSize = true;
            this.lblArchitecture.Location = new System.Drawing.Point(27, 28);
            this.lblArchitecture.Name = "lblArchitecture";
            this.lblArchitecture.Size = new System.Drawing.Size(111, 13);
            this.lblArchitecture.TabIndex = 7;
            this.lblArchitecture.Text = "Architecture Template";
            // 
            // cmbArchitecture
            // 
            this.cmbArchitecture.FormattingEnabled = true;
            this.cmbArchitecture.Items.AddRange(new object[] {
            "PsACPD",
            "InsideRA",
            "Venclyxto",
            "Duopa"});
            this.cmbArchitecture.Location = new System.Drawing.Point(152, 25);
            this.cmbArchitecture.Name = "cmbArchitecture";
            this.cmbArchitecture.Size = new System.Drawing.Size(121, 21);
            this.cmbArchitecture.TabIndex = 8;
            this.cmbArchitecture.SelectedValueChanged += new System.EventHandler(this.cmbArchitecture_SelectedValueChanged);
            // 
            // lblVisualStudioVersion
            // 
            this.lblVisualStudioVersion.AutoSize = true;
            this.lblVisualStudioVersion.Location = new System.Drawing.Point(27, 57);
            this.lblVisualStudioVersion.Name = "lblVisualStudioVersion";
            this.lblVisualStudioVersion.Size = new System.Drawing.Size(106, 13);
            this.lblVisualStudioVersion.TabIndex = 9;
            this.lblVisualStudioVersion.Text = "Visual Studio Version";
            // 
            // cmbVSVersion
            // 
            this.cmbVSVersion.FormattingEnabled = true;
            this.cmbVSVersion.Items.AddRange(new object[] {
            "2012",
            "2013"});
            this.cmbVSVersion.Location = new System.Drawing.Point(152, 54);
            this.cmbVSVersion.Name = "cmbVSVersion";
            this.cmbVSVersion.Size = new System.Drawing.Size(121, 21);
            this.cmbVSVersion.TabIndex = 10;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Location = new System.Drawing.Point(27, 91);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(43, 13);
            this.lblCountry.TabIndex = 11;
            this.lblCountry.Text = "Country";
            // 
            // cmbCountry
            // 
            this.cmbCountry.FormattingEnabled = true;
            this.cmbCountry.Items.AddRange(new object[] {
            "US",
            "UK"});
            this.cmbCountry.Location = new System.Drawing.Point(152, 88);
            this.cmbCountry.Name = "cmbCountry";
            this.cmbCountry.Size = new System.Drawing.Size(121, 21);
            this.cmbCountry.TabIndex = 12;
            // 
            // grpClient
            // 
            this.grpClient.Controls.Add(this.grpWeb);
            this.grpClient.Controls.Add(this.grpCommon);
            this.grpClient.Location = new System.Drawing.Point(30, 225);
            this.grpClient.Name = "grpClient";
            this.grpClient.Size = new System.Drawing.Size(222, 261);
            this.grpClient.TabIndex = 13;
            this.grpClient.TabStop = false;
            this.grpClient.Text = "Client";
            // 
            // grpWeb
            // 
            this.grpWeb.Controls.Add(this.chkWeb);
            this.grpWeb.Controls.Add(this.chkModel);
            this.grpWeb.Location = new System.Drawing.Point(6, 140);
            this.grpWeb.Name = "grpWeb";
            this.grpWeb.Size = new System.Drawing.Size(200, 100);
            this.grpWeb.TabIndex = 9;
            this.grpWeb.TabStop = false;
            this.grpWeb.Text = "Web";
            // 
            // chkModel
            // 
            this.chkModel.AutoSize = true;
            this.chkModel.Location = new System.Drawing.Point(21, 57);
            this.chkModel.Name = "chkModel";
            this.chkModel.Size = new System.Drawing.Size(55, 17);
            this.chkModel.TabIndex = 7;
            this.chkModel.Text = "Model";
            this.chkModel.UseVisualStyleBackColor = true;
            // 
            // grpCommon
            // 
            this.grpCommon.Controls.Add(this.chkServiceCalls);
            this.grpCommon.Controls.Add(this.chkHelpers);
            this.grpCommon.Controls.Add(this.chkUIHandler);
            this.grpCommon.Location = new System.Drawing.Point(6, 20);
            this.grpCommon.Name = "grpCommon";
            this.grpCommon.Size = new System.Drawing.Size(200, 114);
            this.grpCommon.TabIndex = 8;
            this.grpCommon.TabStop = false;
            this.grpCommon.Text = "Common";
            // 
            // chkServiceCalls
            // 
            this.chkServiceCalls.AutoSize = true;
            this.chkServiceCalls.Location = new System.Drawing.Point(21, 65);
            this.chkServiceCalls.Name = "chkServiceCalls";
            this.chkServiceCalls.Size = new System.Drawing.Size(87, 17);
            this.chkServiceCalls.TabIndex = 7;
            this.chkServiceCalls.Text = "Service Calls";
            this.chkServiceCalls.UseVisualStyleBackColor = true;
            // 
            // chkHelpers
            // 
            this.chkHelpers.AutoSize = true;
            this.chkHelpers.Location = new System.Drawing.Point(21, 42);
            this.chkHelpers.Name = "chkHelpers";
            this.chkHelpers.Size = new System.Drawing.Size(62, 17);
            this.chkHelpers.TabIndex = 6;
            this.chkHelpers.Text = "Helpers";
            this.chkHelpers.UseVisualStyleBackColor = true;
            // 
            // grpCore
            // 
            this.grpCore.Controls.Add(this.grpAPIService);
            this.grpCore.Controls.Add(this.grpEntities);
            this.grpCore.Controls.Add(this.grpBAL);
            this.grpCore.Controls.Add(this.grpDAL);
            this.grpCore.Location = new System.Drawing.Point(277, 225);
            this.grpCore.Name = "grpCore";
            this.grpCore.Size = new System.Drawing.Size(216, 261);
            this.grpCore.TabIndex = 14;
            this.grpCore.TabStop = false;
            this.grpCore.Text = "Core";
            // 
            // grpAPIService
            // 
            this.grpAPIService.Controls.Add(this.chkWebAPI);
            this.grpAPIService.Location = new System.Drawing.Point(18, 200);
            this.grpAPIService.Name = "grpAPIService";
            this.grpAPIService.Size = new System.Drawing.Size(181, 54);
            this.grpAPIService.TabIndex = 8;
            this.grpAPIService.TabStop = false;
            this.grpAPIService.Text = "APIService";
            // 
            // chkWebAPI
            // 
            this.chkWebAPI.AutoSize = true;
            this.chkWebAPI.Location = new System.Drawing.Point(15, 19);
            this.chkWebAPI.Name = "chkWebAPI";
            this.chkWebAPI.Size = new System.Drawing.Size(69, 17);
            this.chkWebAPI.TabIndex = 4;
            this.chkWebAPI.Text = "Web API";
            this.chkWebAPI.UseVisualStyleBackColor = true;
            // 
            // grpEntities
            // 
            this.grpEntities.Controls.Add(this.chkEntities);
            this.grpEntities.Location = new System.Drawing.Point(18, 140);
            this.grpEntities.Name = "grpEntities";
            this.grpEntities.Size = new System.Drawing.Size(181, 54);
            this.grpEntities.TabIndex = 7;
            this.grpEntities.TabStop = false;
            this.grpEntities.Text = "Entities";
            // 
            // chkEntities
            // 
            this.chkEntities.AutoSize = true;
            this.chkEntities.Location = new System.Drawing.Point(15, 19);
            this.chkEntities.Name = "chkEntities";
            this.chkEntities.Size = new System.Drawing.Size(60, 17);
            this.chkEntities.TabIndex = 4;
            this.chkEntities.Text = "Entities";
            this.chkEntities.UseVisualStyleBackColor = true;
            // 
            // grpBAL
            // 
            this.grpBAL.Controls.Add(this.chkBAL);
            this.grpBAL.Location = new System.Drawing.Point(18, 80);
            this.grpBAL.Name = "grpBAL";
            this.grpBAL.Size = new System.Drawing.Size(181, 54);
            this.grpBAL.TabIndex = 6;
            this.grpBAL.TabStop = false;
            this.grpBAL.Text = "BAL";
            // 
            // chkBAL
            // 
            this.chkBAL.AutoSize = true;
            this.chkBAL.Location = new System.Drawing.Point(15, 19);
            this.chkBAL.Name = "chkBAL";
            this.chkBAL.Size = new System.Drawing.Size(46, 17);
            this.chkBAL.TabIndex = 4;
            this.chkBAL.Text = "BAL";
            this.chkBAL.UseVisualStyleBackColor = true;
            // 
            // grpDAL
            // 
            this.grpDAL.Controls.Add(this.chkDAL);
            this.grpDAL.Location = new System.Drawing.Point(18, 20);
            this.grpDAL.Name = "grpDAL";
            this.grpDAL.Size = new System.Drawing.Size(181, 54);
            this.grpDAL.TabIndex = 5;
            this.grpDAL.TabStop = false;
            this.grpDAL.Text = "DAL";
            // 
            // chkDAL
            // 
            this.chkDAL.AutoSize = true;
            this.chkDAL.Location = new System.Drawing.Point(17, 19);
            this.chkDAL.Name = "chkDAL";
            this.chkDAL.Size = new System.Drawing.Size(47, 17);
            this.chkDAL.TabIndex = 3;
            this.chkDAL.Text = "DAL";
            this.chkDAL.UseVisualStyleBackColor = true;
            // 
            // grpCrossCutting
            // 
            this.grpCrossCutting.Controls.Add(this.chkAutoMapper);
            this.grpCrossCutting.Controls.Add(this.chkExceptionHandler);
            this.grpCrossCutting.Controls.Add(this.chkWebService);
            this.grpCrossCutting.Controls.Add(this.chkGlobalHandler);
            this.grpCrossCutting.Location = new System.Drawing.Point(524, 225);
            this.grpCrossCutting.Name = "grpCrossCutting";
            this.grpCrossCutting.Size = new System.Drawing.Size(240, 261);
            this.grpCrossCutting.TabIndex = 15;
            this.grpCrossCutting.TabStop = false;
            this.grpCrossCutting.Text = "CrossCutting";
            // 
            // chkAutoMapper
            // 
            this.chkAutoMapper.AutoSize = true;
            this.chkAutoMapper.Location = new System.Drawing.Point(19, 33);
            this.chkAutoMapper.Name = "chkAutoMapper";
            this.chkAutoMapper.Size = new System.Drawing.Size(84, 17);
            this.chkAutoMapper.TabIndex = 3;
            this.chkAutoMapper.Text = "AutoMapper";
            this.chkAutoMapper.UseVisualStyleBackColor = true;
            // 
            // chkExceptionHandler
            // 
            this.chkExceptionHandler.AutoSize = true;
            this.chkExceptionHandler.Location = new System.Drawing.Point(121, 33);
            this.chkExceptionHandler.Name = "chkExceptionHandler";
            this.chkExceptionHandler.Size = new System.Drawing.Size(113, 17);
            this.chkExceptionHandler.TabIndex = 4;
            this.chkExceptionHandler.Text = "Exception Handler";
            this.chkExceptionHandler.UseVisualStyleBackColor = true;
            // 
            // chkWebService
            // 
            this.chkWebService.AutoSize = true;
            this.chkWebService.Location = new System.Drawing.Point(121, 56);
            this.chkWebService.Name = "chkWebService";
            this.chkWebService.Size = new System.Drawing.Size(85, 17);
            this.chkWebService.TabIndex = 5;
            this.chkWebService.Text = "WebService";
            this.chkWebService.UseVisualStyleBackColor = true;
            // 
            // chkGlobalHandler
            // 
            this.chkGlobalHandler.AutoSize = true;
            this.chkGlobalHandler.Location = new System.Drawing.Point(19, 56);
            this.chkGlobalHandler.Name = "chkGlobalHandler";
            this.chkGlobalHandler.Size = new System.Drawing.Size(96, 17);
            this.chkGlobalHandler.TabIndex = 6;
            this.chkGlobalHandler.Text = "Global Handler";
            this.chkGlobalHandler.UseVisualStyleBackColor = true;
            // 
            // lblSelectFolder
            // 
            this.lblSelectFolder.AutoSize = true;
            this.lblSelectFolder.Location = new System.Drawing.Point(30, 153);
            this.lblSelectFolder.Name = "lblSelectFolder";
            this.lblSelectFolder.Size = new System.Drawing.Size(61, 13);
            this.lblSelectFolder.TabIndex = 16;
            this.lblSelectFolder.Text = "Folder Path";
            // 
            // txtFolderPath
            // 
            this.txtFolderPath.Location = new System.Drawing.Point(152, 150);
            this.txtFolderPath.Name = "txtFolderPath";
            this.txtFolderPath.Size = new System.Drawing.Size(100, 20);
            this.txtFolderPath.TabIndex = 17;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(258, 148);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 18;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // grpDB
            // 
            this.grpDB.Controls.Add(this.chkDB);
            this.grpDB.Location = new System.Drawing.Point(787, 225);
            this.grpDB.Name = "grpDB";
            this.grpDB.Size = new System.Drawing.Size(240, 261);
            this.grpDB.TabIndex = 16;
            this.grpDB.TabStop = false;
            this.grpDB.Text = "DB";
            // 
            // chkDB
            // 
            this.chkDB.AutoSize = true;
            this.chkDB.Location = new System.Drawing.Point(19, 33);
            this.chkDB.Name = "chkDB";
            this.chkDB.Size = new System.Drawing.Size(41, 17);
            this.chkDB.TabIndex = 3;
            this.chkDB.Text = "DB";
            this.chkDB.UseVisualStyleBackColor = true;
            // 
            // chkSecurityCryptography
            // 
            this.chkSecurityCryptography.AutoSize = true;
            this.chkSecurityCryptography.Location = new System.Drawing.Point(381, 167);
            this.chkSecurityCryptography.Name = "chkSecurityCryptography";
            this.chkSecurityCryptography.Size = new System.Drawing.Size(129, 17);
            this.chkSecurityCryptography.TabIndex = 19;
            this.chkSecurityCryptography.Text = "Security.Cryptography";
            this.chkSecurityCryptography.UseVisualStyleBackColor = true;
            // 
            // chkModels
            // 
            this.chkModels.AutoSize = true;
            this.chkModels.Location = new System.Drawing.Point(381, 142);
            this.chkModels.Name = "chkModels";
            this.chkModels.Size = new System.Drawing.Size(60, 17);
            this.chkModels.TabIndex = 20;
            this.chkModels.Text = "Models";
            this.chkModels.UseVisualStyleBackColor = true;
            // 
            // chkLogging
            // 
            this.chkLogging.AutoSize = true;
            this.chkLogging.Location = new System.Drawing.Point(381, 119);
            this.chkLogging.Name = "chkLogging";
            this.chkLogging.Size = new System.Drawing.Size(64, 17);
            this.chkLogging.TabIndex = 21;
            this.chkLogging.Text = "Logging";
            this.chkLogging.UseVisualStyleBackColor = true;
            // 
            // chkDataAccess
            // 
            this.chkDataAccess.AutoSize = true;
            this.chkDataAccess.Location = new System.Drawing.Point(381, 96);
            this.chkDataAccess.Name = "chkDataAccess";
            this.chkDataAccess.Size = new System.Drawing.Size(84, 17);
            this.chkDataAccess.TabIndex = 22;
            this.chkDataAccess.Text = "DataAccess";
            this.chkDataAccess.UseVisualStyleBackColor = true;
            // 
            // chkUSWeb
            // 
            this.chkUSWeb.AutoSize = true;
            this.chkUSWeb.Location = new System.Drawing.Point(381, 195);
            this.chkUSWeb.Name = "chkUSWeb";
            this.chkUSWeb.Size = new System.Drawing.Size(49, 17);
            this.chkUSWeb.TabIndex = 23;
            this.chkUSWeb.Text = "Web";
            this.chkUSWeb.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1145, 651);
            this.Controls.Add(this.chkUSWeb);
            this.Controls.Add(this.chkDataAccess);
            this.Controls.Add(this.chkLogging);
            this.Controls.Add(this.chkModels);
            this.Controls.Add(this.chkSecurityCryptography);
            this.Controls.Add(this.grpDB);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtFolderPath);
            this.Controls.Add(this.lblSelectFolder);
            this.Controls.Add(this.grpCrossCutting);
            this.Controls.Add(this.grpCore);
            this.Controls.Add(this.grpClient);
            this.Controls.Add(this.cmbCountry);
            this.Controls.Add(this.lblCountry);
            this.Controls.Add(this.cmbVSVersion);
            this.Controls.Add(this.lblVisualStudioVersion);
            this.Controls.Add(this.cmbArchitecture);
            this.Controls.Add(this.lblArchitecture);
            this.Controls.Add(this.txtProjectName);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.lblProjectName);
            this.Name = "Form1";
            this.grpClient.ResumeLayout(false);
            this.grpWeb.ResumeLayout(false);
            this.grpWeb.PerformLayout();
            this.grpCommon.ResumeLayout(false);
            this.grpCommon.PerformLayout();
            this.grpCore.ResumeLayout(false);
            this.grpAPIService.ResumeLayout(false);
            this.grpAPIService.PerformLayout();
            this.grpEntities.ResumeLayout(false);
            this.grpEntities.PerformLayout();
            this.grpBAL.ResumeLayout(false);
            this.grpBAL.PerformLayout();
            this.grpDAL.ResumeLayout(false);
            this.grpDAL.PerformLayout();
            this.grpCrossCutting.ResumeLayout(false);
            this.grpCrossCutting.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.grpDB.ResumeLayout(false);
            this.grpDB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.TextBox txtProjectName;
        private System.Windows.Forms.CheckBox chkUIHandler;
        private System.Windows.Forms.CheckBox chkWeb;
        private System.Windows.Forms.Label lblArchitecture;
        private System.Windows.Forms.ComboBox cmbArchitecture;
        private System.Windows.Forms.Label lblVisualStudioVersion;
        private System.Windows.Forms.ComboBox cmbVSVersion;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.ComboBox cmbCountry;
        private System.Windows.Forms.GroupBox grpClient;
        private System.Windows.Forms.GroupBox grpCore;
        private System.Windows.Forms.CheckBox chkDAL;
        private System.Windows.Forms.CheckBox chkBAL;
        private System.Windows.Forms.GroupBox grpCrossCutting;
        private System.Windows.Forms.CheckBox chkAutoMapper;
        private System.Windows.Forms.CheckBox chkExceptionHandler;
        private System.Windows.Forms.CheckBox chkWebService;
        private System.Windows.Forms.CheckBox chkGlobalHandler;
        private System.Windows.Forms.CheckBox chkModel;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Label lblSelectFolder;
        private System.Windows.Forms.TextBox txtFolderPath;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.GroupBox grpWeb;
        private System.Windows.Forms.GroupBox grpCommon;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.GroupBox grpBAL;
        private System.Windows.Forms.GroupBox grpDAL;
        private System.Windows.Forms.GroupBox grpEntities;
        private System.Windows.Forms.CheckBox chkEntities;
        private System.Windows.Forms.CheckBox chkHelpers;
        private System.Windows.Forms.CheckBox chkServiceCalls;
        private System.Windows.Forms.GroupBox grpAPIService;
        private System.Windows.Forms.CheckBox chkWebAPI;
        private System.Windows.Forms.GroupBox grpDB;
        private System.Windows.Forms.CheckBox chkDB;
        private System.Windows.Forms.CheckBox chkUSWeb;
        private System.Windows.Forms.CheckBox chkDataAccess;
        private System.Windows.Forms.CheckBox chkLogging;
        private System.Windows.Forms.CheckBox chkModels;
        private System.Windows.Forms.CheckBox chkSecurityCryptography;
    }
}

