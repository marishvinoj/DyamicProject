﻿using EnvDTE;
using Microsoft.CSharp;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Runtime.InteropServices;

namespace DynamicProjectCreator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateDynamicProject();
        }

        private void CreateDynamicProject()
        {
            string VS2012CL = System.Configuration.ConfigurationManager.AppSettings["VS2012CL"];
            string VS2012EMVC = System.Configuration.ConfigurationManager.AppSettings["VS2012EMVC"];

            var res = Common.GetEnumDescription((VisualStudioVersion)Enum.Parse(typeof(VisualStudioVersion), cmbVSVersion.SelectedItem.ToString()));
            //System.Type type = System.Type.GetTypeFromProgID("VisualStudio.DTE.11.0");
            System.Type type = System.Type.GetTypeFromProgID(res);
            Object obj = System.Activator.CreateInstance(type, true);
            DTE dte = (EnvDTE.DTE)obj;


            dte.MainWindow.Visible = true; // optional if you want to See VS doing its thing
            MessageFilter.Register();
            // Display the Visual Studio IDE.
            dte.MainWindow.Activate();



            if (Common.GetEnumDescription(ArchTemplate.PsACPD) == cmbArchitecture.Text)
            {
                var currenttime = DateTime.Now.ToString("yyyyMMddHHmmss");
                var commonPath = @"D:\DyanamicProjects" + currenttime + "\\";

                var UIHandlerPath = commonPath + grpClient.Text + "\\" + grpCommon.Text + "\\" + chkUIHandler.Text + "\\";

                // create a new solution
                dte.Solution.Create(@"D:\DyanamicProjects" + currenttime + "\\" + grpClient.Text, "test");
                //dte.Solution.Create(UIHandlerPath, "test");
                var solution = dte.Solution;


                var commonAssemblyFolder = @"d:\DyanamicProjects" + currenttime + "\\" + "Assembly";

                // create a C# WinForms app
                solution.AddFromTemplate(VS2012CL,
                                        UIHandlerPath, chkUIHandler.Text);

                var WebPath = commonPath + grpClient.Text + "\\" + grpWeb.Text + "\\" + chkWeb.Text;

                solution.AddFromTemplate(VS2012EMVC,
                                         WebPath, chkWeb.Text);

                var ModelPath = commonPath + grpClient.Text + "\\" + grpWeb.Text + "\\" + chkModel.Text + "\\";

                // create a C# class library
                solution.AddFromTemplate(VS2012CL,
                      ModelPath, chkModel.Text);

                var DALPath = commonPath + grpCore.Text + "\\" + grpDAL.Text + "\\" + chkDAL.Text + "\\";

                // create a C# class library
                solution.AddFromTemplate(VS2012CL,
                      DALPath, chkDAL.Text);

                var BALPath = commonPath + grpCore.Text + "\\" + grpBAL.Text + "\\" + chkBAL.Text + "\\";

                // create a C# class library
                solution.AddFromTemplate(VS2012CL,
                      BALPath, chkBAL.Text);

                var EntitiesPath = commonPath + grpCore.Text + "\\" + grpEntities.Text + "\\" + chkEntities.Text + "\\";

                // create a C# class library
                solution.AddFromTemplate(VS2012CL,
                      EntitiesPath, chkEntities.Text);

                var list = new List<string> { UIHandlerPath, ModelPath };

                var coreList = new List<string> { DALPath, BALPath, EntitiesPath };

                //var item = list.FirstOrDefault();
                foreach (var item in list)
                {
                    var path = string.Empty;
                    if (item == UIHandlerPath)
                        path = UIHandlerPath + "Class1.cs";
                    else
                        path = ModelPath + "Class1.cs";

                    GenerateDynamicDLL(currenttime, UIHandlerPath, solution, ModelPath, item, path);
                }

                foreach (var item in coreList)
                {
                    var path = string.Empty;
                    if (item == DALPath)
                        path = DALPath + "Class1.cs";
                    else if (item == BALPath)
                        path = BALPath + "Class1.cs";
                    else if (item == EntitiesPath)
                        path = EntitiesPath + "Class1.cs";

                    GenerateDynamicDLL(currenttime, UIHandlerPath, solution, ModelPath, item, path, true);
                }

            }

            // save and quit
            dte.ExecuteCommand("File.SaveAll");
            dte.Quit();
            MessageFilter.Revoke();
        }

        private void GenerateDynamicDLL(string currenttime, string UIHandlerPath, Solution solution, string ModelPath, string item, string path, bool coreFlag = false)
        {
            //string text = File.ReadAllText(path);
            //text = text.Replace("using System.Threading.Tasks;", "");
            //text = text.Replace("using System.Linq;", "");
            //File.WriteAllText(path, text);

            string text = File.ReadAllText(path);

            // Write the string to a file.
            System.IO.StreamWriter file = new System.IO.StreamWriter(path);
            text = text.Replace("using System.Threading.Tasks;", "");
            text = text.Replace("using System.Linq;", "");
            file.WriteLine(text);
            file.Dispose();
            file.Close();

            CSharpCodeProvider codeProvider = new CSharpCodeProvider();
            ICodeCompiler icc = codeProvider.CreateCompiler();
            System.CodeDom.Compiler.CompilerParameters parameters = new CompilerParameters();
            parameters.GenerateExecutable = false;


            string pathString = System.IO.Path.Combine(@"d:\DyanamicProjects" + currenttime + "\\", "Assembly\\");
            bool exists = System.IO.Directory.Exists(pathString);
            if (!exists)
                System.IO.Directory.CreateDirectory(pathString);

            //parameters.OutputAssembly = @"d:\DyanamicProjectsAssembly\ClassLibrary2.dll";
            //parameters.OutputAssembly = (item == UIHandlerPath) ? pathString + chkUIHandler.Text + ".dll" : pathString + chkModel.Text + ".dll";
            if (!coreFlag)
            {
                parameters.OutputAssembly = (item == UIHandlerPath) ? pathString + chkUIHandler.Text + ".dll" : pathString + chkModel.Text + ".dll";
            }
            else if (coreFlag) 
            {
                var dll = string.Empty;
                if (item.Contains("DAL")) 
                {
                    dll = "DAL.dll";   
                }
                else if (item.Contains("BAL")) 
                {
                    dll = "BAL.dll";
                }
                else if (item.Contains("Entities"))
                {
                    dll = "Entities.dll";
                }
                parameters.OutputAssembly = pathString + dll;
            }

            CompilerResults results = icc.CompileAssemblyFromSource(parameters, text);


            foreach (EnvDTE.Project proj in solution.Projects)
            {
                if (!coreFlag)
                {
                    if (proj.Name == chkWeb.Text && item == UIHandlerPath)
                    {
                        VSLangProj.VSProject vsProject = (VSLangProj.VSProject)proj.Object;

                        vsProject.References.Add(@"d:\DyanamicProjects" + currenttime + "\\" + "Assembly\\" + chkUIHandler.Text + ".dll");
                        break;
                    }
                    else if (proj.Name == chkWeb.Text && item == ModelPath)
                    {
                        VSLangProj.VSProject vsProject = (VSLangProj.VSProject)proj.Object;

                        vsProject.References.Add(@"d:\DyanamicProjects" + currenttime + "\\" + "Assembly\\" + chkModel.Text + ".dll");
                        break;
                    } 
                }
                else if (coreFlag) 
                {
                    if (proj.Name == chkBAL.Text && item.Contains("Entities"))
                    {
                        VSLangProj.VSProject vsProject = (VSLangProj.VSProject)proj.Object;

                        vsProject.References.Add(@"d:\DyanamicProjects" + currenttime + "\\" + "Assembly\\" + chkEntities.Text + ".dll");
                        break;
                    }
                    else if (proj.Name == chkBAL.Text && item.Contains("DAL"))
                    {
                        VSLangProj.VSProject vsProject = (VSLangProj.VSProject)proj.Object;

                        vsProject.References.Add(@"d:\DyanamicProjects" + currenttime + "\\" + "Assembly\\" + chkDAL.Text + ".dll");
                        break;
                    }
                }
            }
        }

        //private string setDynamicDLL(string item)
        //{
        //    var dll = string.Empty;
        //    switch (item)
        //    {
        //        case item.Contains("DAL"):
        //            dll = "DAL.dll";
        //            break;
        //        case "BAL":
        //            dll = "BAL.dll";
        //            break;
        //        case "Entities":
        //            dll = "Entities.dll";
        //            break;
        //        default:
        //            break;
        //    }
        //    return dll;
        //}

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                txtFolderPath.Text = dlg.SelectedPath;
            }
        }

        private void cmbArchitecture_SelectedValueChanged(object sender, EventArgs e)
        {
            var objarch = (ComboBox)sender;
            //obj.SelectedItem
            var arch = (ArchTemplate)Enum.Parse(typeof(ArchTemplate), objarch.SelectedItem.ToString());

            List<string> controlNames = new List<string>();

            List<CheckBox> chkBoxControls = new List<CheckBox>();
            List<GroupBox> chkGroupBox = new List<GroupBox>();

            GetControlName(controlNames, chkBoxControls, chkGroupBox);

            foreach (var item in chkBoxControls)
            {
                item.Show();
            }

            foreach (var item in chkGroupBox)
            {
                item.Show();
            }

            //grpClient.Show();
            //grpCommon.Show();
            //chkUIHandler.Show();
            //chkHelpers.Show();
            //chkServiceCalls.Show();

            //grpWeb.Show();
            //chkWeb.Show();
            //chkModel.Show();

            //grpCore.Show();
            //grpDAL.Show();
            //chkDAL.Show();

            //grpBAL.Show();
            //chkBAL.Show();

            //grpEntities.Show();
            //chkEntities.Show();


            //grpAPIService.Show();

            //grpDAL.Show();


            //grpCrossCutting.Show();

            //grpDB.Show();

            if (ArchTemplate.Duopa != arch)
            {
                chkDataAccess.Hide();
                chkLogging.Hide();
                chkModels.Hide();
                chkSecurityCryptography.Hide();
                chkUSWeb.Hide();
            }

            if (ArchTemplate.PsACPD == arch)
            {
                chkUIHandler.Show();
                chkHelpers.Hide();
                chkServiceCalls.Hide();
                grpAPIService.Hide();
                grpDB.Hide();
            }
            else if (ArchTemplate.InsideRA == arch)
            {
                chkUIHandler.Hide();
                chkHelpers.Show();
                chkServiceCalls.Show();
                grpAPIService.Show();
                grpDB.Show();
            }
            else if (ArchTemplate.Venclyxto == arch)
            {
                grpClient.Hide();
                grpBAL.Hide();
                grpEntities.Hide();
                grpAPIService.Show();
                grpCrossCutting.Hide();
                grpDB.Hide();
            }
            else if (ArchTemplate.Duopa == arch)
            {
                grpClient.Hide();
                grpCore.Hide();
                grpCrossCutting.Hide();
                grpDB.Hide();

                chkDataAccess.Show();
                chkLogging.Show();
                chkModels.Show();
                chkSecurityCryptography.Show();
                chkUSWeb.Show();
            }
        }


        private void GetControlName(List<string> controlNames, List<CheckBox> chkBoxControls, List<GroupBox> chkGroupBox)
        {
            foreach (Control c in this.Controls)
            {
                if (c is CheckBox || c is GroupBox)
                {
                    // Do stuff here ;]
                    if (c is CheckBox)
                    {
                        var chk = (CheckBox)c;
                        chkBoxControls.Add(chk);
                    }
                    else if (c is GroupBox)
                    {
                        var grp = (GroupBox)c;
                        chkGroupBox.Add(grp);
                    }
                    controlNames.Add(c.Name);
                    if (c is GroupBox)
                    {
                        foreach (Control item in c.Controls)
                        {
                            if (item is CheckBox || item is GroupBox)
                            {
                                // Do stuff here ;]
                                if (item is CheckBox)
                                {
                                    var chk = (CheckBox)item;
                                    chkBoxControls.Add(chk);
                                }
                                else if (item is GroupBox)
                                {
                                    var grp = (GroupBox)item;
                                    chkGroupBox.Add(grp);
                                }
                                controlNames.Add(item.Name);
                            }

                            foreach (var item1 in item.Controls)
                            {
                                if (item1 is CheckBox || item1 is GroupBox)
                                {
                                    // Do stuff here ;]
                                    if (item1 is CheckBox)
                                    {
                                        var chk = (CheckBox)item1;
                                        chkBoxControls.Add(chk);
                                    }
                                    else if (item1 is GroupBox)
                                    {
                                        var grp = (GroupBox)item1;
                                        chkGroupBox.Add(grp);
                                    }
                                    //controlNames.Add(item.Name);
                                }
                            }

                        }
                    }
                }
            }
        }

    }

    public static class Common
    {
        /// <summary>
        /// To get the enum description
        /// </summary>
        /// <param >Enum value</param>
        /// <returns>Enum description</returns>
        public static string GetEnumDescription<TEnum>(this TEnum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            if (fi != null)
            {
                var attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes.Length > 0)
                    return attributes[0].Description;
            }

            return value.ToString();
        }
    }

    public enum VisualStudioVersion
    {
        [Description("VisualStudio.DTE.11.0")]
        VS2012 = 2012,
        [Description("VisualStudio.DTE.12.0")]
        VS2013 = 2013,
    }

    public enum ArchTemplate
    {
        [Description("PsACPD")]
        PsACPD = 1,
        [Description("InsideRA")]
        InsideRA = 2,
        [Description("Venclyxto")]
        Venclyxto = 3,

        [Description("Duopa")]
        Duopa = 4,
    }


    public class MessageFilter : IOleMessageFilter
    {
        //
        // Class containing the IOleMessageFilter
        // thread error-handling functions.

        // Start the filter.
        public static void Register()
        {
            IOleMessageFilter newFilter = new MessageFilter();
            IOleMessageFilter oldFilter = null;
            CoRegisterMessageFilter(newFilter, out oldFilter);
        }

        // Done with the filter, close it.
        public static void Revoke()
        {
            IOleMessageFilter oldFilter = null;
            CoRegisterMessageFilter(null, out oldFilter);
        }

        //
        // IOleMessageFilter functions.
        // Handle incoming thread requests.
        int IOleMessageFilter.HandleInComingCall(int dwCallType,
          System.IntPtr hTaskCaller, int dwTickCount, System.IntPtr
          lpInterfaceInfo)
        {
            //Return the flag SERVERCALL_ISHANDLED.
            return 0;
        }

        // Thread call was rejected, so try again.
        int IOleMessageFilter.RetryRejectedCall(System.IntPtr
          hTaskCallee, int dwTickCount, int dwRejectType)
        {
            if (dwRejectType == 2)
            // flag = SERVERCALL_RETRYLATER.
            {
                // Retry the thread call immediately if return >=0 & 
                // <100.
                return 99;
            }
            // Too busy; cancel call.
            return -1;
        }

        int IOleMessageFilter.MessagePending(System.IntPtr hTaskCallee,
          int dwTickCount, int dwPendingType)
        {
            //Return the flag PENDINGMSG_WAITDEFPROCESS.
            return 2;
        }

        // Implement the IOleMessageFilter interface.
        [DllImport("Ole32.dll")]
        private static extern int
          CoRegisterMessageFilter(IOleMessageFilter newFilter, out 
          IOleMessageFilter oldFilter);
    }

    [ComImport(), Guid("00000016-0000-0000-C000-000000000046"),
    InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
    interface IOleMessageFilter
    {
        [PreserveSig]
        int HandleInComingCall(
            int dwCallType,
            IntPtr hTaskCaller,
            int dwTickCount,
            IntPtr lpInterfaceInfo);

        [PreserveSig]
        int RetryRejectedCall(
            IntPtr hTaskCallee,
            int dwTickCount,
            int dwRejectType);

        [PreserveSig]
        int MessagePending(
            IntPtr hTaskCallee,
            int dwTickCount,
            int dwPendingType);
    }

}
